</body>
<div class="container-fluid text-center p-0" style="background-color:#797c80">
    <div class="row">
        <div class="col-6 col-sm-12">
            <h4>Osnovne informacije</h4>
            <a href="">O nama</a>
            <p>Kontakt:</p>
            <p>Instagram:</p>
            <p>Facebook:</p>
        </div>


        <div class="col-6 col-sm-3 offset-2">
            <h5>Lokacija</h5>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22678.925144857574!2d17.300979585790373!3d44.72235354854545!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475e10037ef43d95%3A0x4b930955a9b45eaf!2zxIxlbGluYWM!5e0!3m2!1shr!2sba!4v1697468194991!5m2!1shr!2sba" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

    </div>




</div>
</html>
