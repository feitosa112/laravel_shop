<div class="row">
    <div class="col-12">
        <h5 class="slikalogo1">Moj online shop</h5>
    </div>
</div>
<div class="row">
    <div class="col-3">
        <h4 class="slikalogo">Moj online shop</h4>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-6 mx-auto">
        <form action="{{route('search')}}">
            <div class="input-group mb-3">
                <input type="text" placeholder="Search" name="search" class="form-control">
                <div class="input-group-append">
                    <button class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i> Search</button>
                </div>
            </div>
        </form>

    </div>
 </div>
